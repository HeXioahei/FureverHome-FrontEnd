<template>
  <div>
    <h1>Pet Forum</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>
</style>