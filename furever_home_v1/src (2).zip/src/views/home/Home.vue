<template>
  <div>
    <h1>这是首页，进行平台的简介并欢迎用户</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>
</style>