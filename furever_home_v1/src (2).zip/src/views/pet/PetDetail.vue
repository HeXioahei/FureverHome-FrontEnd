<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { pets, type Pet } from '@/data/pets'

const route = useRoute()
const router = useRouter()

const petId = computed(() => Number(route.params.id))

const currentPet = computed<Pet | undefined>(() =>
  pets.find((p) => p.id === petId.value)
)

const goBack = () => {
  router.push('/')
}

const goToFostererProfile = () => {
  // TODO: 未来接入临时收养者主页路由
  console.log('查看主页')
}

const contactFosterer = () => {
  // TODO: 未来接入聊天/私信功能
  console.log('联系TA')
}
</script>

<template>
  <div class="bg-background-light dark:bg-background-dark font-display text-slate-700 dark:text-slate-300 min-h-screen">
    <main v-if="currentPet" class="container mx-auto px-6 py-8">
      <div class="space-y-8">
        <!-- 顶部卡片 -->
        <div class="relative bg-white dark:bg-zinc-800 rounded-lg shadow-sm p-8">
          <button
            type="button"
            class="absolute top-8 right-8 flex items-center text-sm text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
            @click="goBack"
          >
            <span class="material-icons text-base mr-1">arrow_back_ios_new</span>
            <span>返回宠物列表</span>
          </button>

          <div class="flex flex-col lg:flex-row lg:space-x-8 space-y-6 lg:space-y-0">
            <!-- 图片区域 -->
            <div class="lg:w-1/3 w-full">
              <div class="bg-amber-100 rounded-lg aspect-[4/3] flex items-center justify-center">
                <p class="text-amber-600 dark:text-amber-400">{{ currentPet.photoText }}</p>
              </div>
            </div>

            <!-- 基本信息 -->
            <div class="lg:w-2/3 w-full flex flex-col">
              <div class="flex-grow">
                <h1 class="text-4xl font-bold text-primary mb-2">
                  {{ currentPet.name }}
                </h1>
                <p class="text-slate-500 dark:text-slate-400 mb-6">
                  {{ currentPet.species === 'cat' ? '猫咪' : '狗狗' }} · {{ currentPet.location }}
                </p>

                <div class="grid grid-cols-2 gap-x-8 gap-y-4 text-sm">
                  <div class="border-b border-slate-200 dark:border-zinc-700 pb-3">
                    <p class="text-slate-500 dark:text-slate-400">性别</p>
                    <p class="font-medium text-slate-800 dark:text-slate-200 mt-1">
                      {{ currentPet.gender === 'male' ? '公' : '母' }}
                    </p>
                  </div>
                  <div class="border-b border-slate-200 dark:border-zinc-700 pb-3">
                    <p class="text-slate-500 dark:text-slate-400">年龄</p>
                    <p class="font-medium text-slate-800 dark:text-slate-200 mt-1">
                      {{ currentPet.age }}岁
                    </p>
                  </div>
                  <div class="border-b border-slate-200 dark:border-zinc-700 pb-3">
                    <p class="text-slate-500 dark:text-slate-400">健康状况</p>
                    <p class="font-medium text-slate-800 dark:text-slate-200 mt-1">良好</p>
                  </div>
                  <div class="border-b border-slate-200 dark:border-zinc-700 pb-3">
                    <p class="text-slate-500 dark:text-slate-400">性情特点</p>
                    <p class="font-medium text-slate-800 dark:text-slate-200 mt-1">亲人、温顺</p>
                  </div>
                  <div>
                    <p class="text-slate-500 dark:text-slate-400">目前位置</p>
                    <p class="font-medium text-slate-800 dark:text-slate-200 mt-1">xx大学</p>
                  </div>
                </div>
              </div>

              <div class="bg-amber-50 dark:bg-zinc-700/50 rounded-lg p-4 mt-6">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <span
                      class="inline-block bg-amber-200 text-amber-800 dark:bg-amber-900 dark:text-amber-200 text-xs font-semibold px-2 py-1 rounded-full mb-2"
                    >
                      {{ currentPet.adoption_status === 'available' ? '短期领养' : '长期领养' }}
                    </span>
                    <p class="text-sm text-slate-600 dark:text-slate-300">
                      当前领养状态：
                      {{ currentPet.adoption_status === 'available' ? '短期领养' : '长期领养' }}
                    </p>
                    <div class="flex items-center mt-3">
                      <div class="h-10 w-10 rounded-full bg-slate-300" />
                      <div class="ml-3">
                        <p class="text-xs text-slate-500 dark:text-slate-400 mb-0.5">
                          {{ currentPet.adoption_status === 'available' ? '短期收养者' : '长期收养者' }}
                        </p>
                        <p class="font-semibold text-slate-800 dark:text-slate-200">
                          {{ currentPet.fosterer }}
                        </p>
                        <div class="flex items-center text-xs">
                          <span class="text-slate-500 dark:text-slate-400 mr-1">评分: 4.9</span>
                          <span class="text-amber-400">★★★★</span><span class="text-amber-300">★</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="flex items-center space-x-3">
                    <button
                      type="button"
                      class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
                      @click="goToFostererProfile"
                    >
                      查看主页
                    </button>
                    <button
                      type="button"
                      class="bg-primary hover:bg-orange-500 text-white font-bold py-2 px-4 rounded-lg transition-colors bg-orange-500"
                      @click="contactFosterer"
                    >
                      联系TA
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 下方信息区 -->
        <div class="bg-white dark:bg-zinc-800 rounded-lg shadow-sm p-8">
          <div class="space-y-8">
            <section>
              <h2 class="text-2xl font-bold text-primary mb-3">宠物简介</h2>
              <p class="leading-relaxed text-slate-600 dark:text-slate-300">
                小橘是一只非常亲人的橘猫，于2022年在xx大学被发现。性格活泼好动，喜欢与人互动，特别喜欢被挠下巴，已经完成绝育手术和所有必要疫苗，身体健康，无任何传染病史。
              </p>
            </section>

            <hr class="border-slate-200 dark:border-zinc-700" />

            <section>
              <h2 class="text-2xl font-bold text-primary mb-3">关于{{ currentPet.name }}</h2>
              <p class="leading-relaxed text-slate-600 dark:text-slate-300">
                小橘是2022年秋天在xx大学被发现的流浪小猫，当时只有两个月大，被李同学救助并临时收养至今，已经健康成长为一只活泼可爱的猫咪。小橘性格异常温顺，喜欢与人互动，会主动蹭腿示好，特别喜欢玩逗猫棒和在线球，作息规律，已经学会使用猫砂盆，非常适合家庭培养。作为临时收养者，李同学已为小橘完成绝育、三联疫苗和体外驱虫，健康状况良好，希望能为小橘找到一个有爱心、负责任的长期家庭。
              </p>
            </section>

            <hr class="border-slate-200 dark:border-zinc-700" />

            <section>
              <h2 class="text-2xl font-bold text-primary mb-4">生活照片</h2>
              <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-slate-100 dark:bg-zinc-700 rounded-lg aspect-square flex items-center justify-center">
                  <p class="text-slate-400 dark:text-slate-500 text-sm">照片1</p>
                </div>
                <div class="bg-slate-100 dark:bg-zinc-700 rounded-lg aspect-square flex items-center justify-center">
                  <p class="text-slate-400 dark:text-slate-500 text-sm">照片2</p>
                </div>
                <div class="bg-slate-100 dark:bg-zinc-700 rounded-lg aspect-square flex items-center justify-center">
                  <p class="text-slate-400 dark:text-slate-500 text-sm">照片3</p>
                </div>
                <div class="bg-slate-100 dark:bg-zinc-700 rounded-lg aspect-square flex items-center justify-center">
                  <p class="text-slate-400 dark:text-slate-500 text-sm">照片4</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>

    <main v-else class="container mx-auto px-6 py-16">
      <div class="bg-white dark:bg-zinc-800 rounded-lg shadow-sm p-10 text-center">
        <p class="text-xl font-semibold mb-4">未找到该宠物信息</p>
        <button
          type="button"
          class="mt-2 inline-flex items-center justify-center px-4 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium"
          @click="goBack"
        >
          返回宠物列表
        </button>
      </div>
    </main>
  </div>
</template>
